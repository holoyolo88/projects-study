# ChatterBox_chagedUI_addedFunctions_integratedDB
----------
It is a simple one to all chatting program using TCP.
## How To Use
Please change database and IP settings with code!  

A client have to sign up or login to use this program.

A client can send and receive message to the clients who are connected with server.

A client can also get previous chatting data.


## How To Make
2018-8-25  
made EntityRelationShipDiagram and database using MySql
![entityrelationshipdiagram](https://user-images.githubusercontent.com/30407766/44946893-b9e89400-ae3f-11e8-99f1-2665fa2894e1.png)


2018-9-1  
made UseCase using StarUML  
![usecasediagram](https://user-images.githubusercontent.com/30407766/44946866-3464e400-ae3f-11e8-9085-f56a1356fc69.png)


2018-9-1  
made ClassDiagrm using EclipseObjectAid
![classdiagram](https://user-images.githubusercontent.com/30407766/44946894-bead4800-ae3f-11e8-8808-0f8e981237bb.png)

2018-9-2  
made SequenceDiagram using StarUML  
![sequencediagram](https://user-images.githubusercontent.com/30407766/44951707-28603d00-aea6-11e8-83e4-6809961f7635.png)