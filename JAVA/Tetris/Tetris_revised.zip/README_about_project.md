# Tetris_revised version
----------
It is a tetris game for maximum 2 players.
## How To Use

A User can select options about the number of player and the speed of the game.

Other usage is specified on the game panel.

## Revisions
* 2018-8-9 changed the board color
* 2018-8-10 made previewing tile function
* 2018-8-11 added tetris BGM
